
<?php
require_once "signin.php";



#echo $GLOBALS['password'] . "<br>";
echo $_SESSION['password'];





?>